package de.game.bag_chal.main;

import de.game.bag_chal.model.Model;
import de.game.bag_chal.view.View;
import de.game.bag_chal.control.Control;

public class Main {
	/**
	 * Die Main Startet das Spiel.
	 * 
	 * @param args Nicht verwendet
	 */
	public static void main(String[] args) {
		Model model = new Model();
		View view = new View(model);
		Control control = new Control(model, view);
		control.startGame();
	}

}
