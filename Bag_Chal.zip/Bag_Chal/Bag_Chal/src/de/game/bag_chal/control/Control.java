package de.game.bag_chal.control;
import de.game.bag_chal.view.View;
import de.game.bag_chal.model.Model;
/**
 * Der Controler steuert den Spielablauf und nimmt die Nutzereingaben entgegen. <br>
 * Diese Klasse repr�sentiert die "Control" des MVC-Paradigma.
 * 
 * @author Tobias Sigmann
 *
 */

public class Control {

	/**
	 * Instanz der Klasse Model, in der die zu zeichnenden Werte enthalten sind. {@link Model}
	 */
	Model model;
	
	/**
	 * Instanz der Klasse View, in der die Ausgaben realisiert sind. {@link View}
	 */
	View view;
	
	/**
	 * Input ist eine Instanz der Klasse Eingabe und regaliert die Benutzereingabe. {@link Eingabe}
	 */
	Eingabe input = new Eingabe();
	
	/**
	 * Conrol initialisiert den Zugriff auf die Instanzen der Klassen View und Model.
	 * 
	 * 
	 * @param model Das zu verwendende Model {@link Model}.
	 * @param view Die zu verwendete View. {@link View}
	 */
	public Control(Model model, View view) {
		this.model = model;
		this.view = view;
	}
	

	/**
	 * StartGame dient zum starten des Spiels, hier werden die Abl�ufe gesteuert.
	 */
	public void startGame() {
		model.startGame();
		while (model.isInGame()) {
			view.printField();
			view.printPlayer();
			if (!model.isPlayer() && model.isGoatSetMode()) {
				int row;
				int column;
				view.printSelectRow(true);
				row = input.readInt();
				view.printSelectColumn(true);
				column = input.readInt();
				int userErrorType = model.setGoatLocation(row, column);
				view.printUserSetSheepError(userErrorType);
			} else {
				int startRow, startColumn, targetRow, targetColumn;
				view.printSelectRow(true);
				startRow = input.readInt();
				view.printSelectColumn(true);
				startColumn = input.readInt();
				view.printSelectRow(false);
				targetRow = input.readInt();
				view.printSelectColumn(false);
				targetColumn = input.readInt();
				int userErrorType = model.setMovement(startRow, startColumn, targetRow, targetColumn);
				view.printUserMoveError(userErrorType);
			}
		}
		view.printField();
		view.printWinner(!model.isPlayer());
	}
}
