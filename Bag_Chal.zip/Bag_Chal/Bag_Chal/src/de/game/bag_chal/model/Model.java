package de.game.bag_chal.model;
/**
 * Das Model Speicher das Spielfeld und das Spielfeld des Spieles BagChal. 
 * Weiterhin sind hier auch die Regel des Spiels �berpr�ft.
 * Diese Klasse repr�sentiert die "Model" des MVC-Paradigma.
 * <br>
 * Regeln:
 * 	<ol>
 * 		<li>Die Tiger beginnen in den 4 Ecken des Spielfelds.</li>
 * 		<li>Die Ziegen betreten das Spielfeld einzeln, nacheinander. Jedes Mal wenn
 * 			eine Ziege in das Spielfeld gestellt wird, darf einer der Tiger einen Zug
 * 			ausf�hren (Von einem Punkt zum n�chsten oder Sprung �ber eine
 * 			Ziege). Keine der Ziegen darf bewegt werden, bis alle sich Ziegen im
 * 			Spiel befinden.</li>
 * 		<li>Die Tiger d�rfen sich von ein einem Punkt zum anderen bewegen oder in
 * 			gerader Linie �ber eine Ziege springen. Dabei fressen sie die Ziege und
 * 			entfernen diese vom Spielfeld.</li>
 * 		<li>Es darf jeweils immer nur ein Zug ausgef�hrt werden: Zug Ziege, Zug
 * 			Tiger, Zug Ziege, Zug Tiger�</li>
 * 		<li>Ein Zug (au�er beim Fressen einer Ziege) geht immer nur von einem
 * 			Punkt zum N�chsten.</li>
 * 		<li>Die Ziegen sch�tzen sich, indem sie versuchen zu verhindern, dass ein
 * 			Tiger sie �berspringt. Dies geschieht durch blockieren des m�glichen
 * 			Sprungpunktes f�r den Tiger.</li>
 * 		<li>Wenn die Tiger 8 Ziegen gefressen haben wird es f�r die Ziegen sehr
 * 			schwer, meist ist die Entscheidung dann f�r die Tiger gefallen.</li>
 * 		<li>Wenn die Ziegen alle Tiger derart umzingelt haben, das diese keinen
 * 			Zug mehr ausf�hren k�nnen, haben die Ziegen gewonnen.</li>
 * 	</ol>
 * Quelle der Regeln: http://daten.claudiasbazar.de/Daten/tiger_goat.pdf.
 * 
 * 
 * @author Tobias Sigmann
 */
public class Model {

	/**
	 * Repr�sentiert das Spielfeld. 0=Frei 1=Ziege 2=Tiger
	 */
	private int[][] field = new int[][]	{{ 2, 0, 0, 0, 2 },
										 { 0, 0, 0, 0, 0 },
										 { 0, 0, 0, 0, 0 },
										 { 0, 0, 0, 0, 0 },
										 { 2, 0, 0, 0, 2 }};
											 
	/**
	 * Wird zur Hilfe der �berpr�fung genutzt. 0=Kein Weg dort hin 1=erreichen durch eine Zug m�glich, 2=erreichen durch Sprung m�glich.
	 */
	private int[][] zuege = {{ 0, 1, 2, 0, 0, 1, 1, 0, 0, 0, 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
							{ 1, 0, 1, 2, 0, 0, 1, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
							{ 2, 1, 0, 1, 2, 0, 1, 1, 1, 0, 2, 0, 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
							{ 0, 2, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
							{ 0, 0, 2, 1, 0, 0, 0, 0, 1, 1, 0, 0, 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
							{ 1, 0, 0, 0, 0, 0, 1, 2, 0, 0, 1, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
							{ 1, 1, 1, 0, 0, 1, 0, 1, 2, 0, 1, 1, 1, 0, 0, 0, 2, 0, 2, 0, 0, 0, 0, 0, 0 },
							{ 0, 0, 1, 0, 0, 2, 1, 0, 1, 2, 0, 0, 1, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0 },
							{ 0, 0, 1, 1, 1, 0, 2, 1, 0, 1, 0, 0, 1, 1, 1, 0, 2, 0, 2, 0, 0, 0, 0, 0, 0 },
							{ 0, 0, 0, 0, 1, 0, 0, 2, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0 },
							{ 2, 0, 2, 0, 0, 1, 1, 0, 0, 0, 0, 1, 2, 0, 0, 1, 1, 0, 0, 0, 2, 0, 2, 0, 0 },
							{ 0, 2, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 2, 0, 0, 1, 0, 0, 0, 0, 2, 0, 0, 0 },
							{ 2, 0, 2, 0, 2, 0, 1, 1, 1, 0, 2, 1, 0, 1, 2, 0, 1, 1, 1, 0, 2, 0, 2, 0, 2 },
							{ 0, 0, 0, 2, 0, 0, 0, 0, 1, 0, 0, 2, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 2, 0 },
							{ 0, 0, 2, 0, 2, 0, 0, 0, 1, 1, 0, 0, 2, 1, 0, 0, 0, 0, 1, 1, 0, 0, 2, 0, 2 },
							{ 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 2, 0, 0, 1, 0, 0, 0, 0 },
							{ 0, 0, 0, 0, 0, 0, 2, 0, 2, 0, 1, 1, 1, 0, 0, 1, 0, 1, 2, 0, 1, 1, 1, 0, 0 },
							{ 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 1, 0, 0, 2, 1, 0, 1, 2, 0, 0, 1, 0, 0 },
							{ 0, 0, 0, 0, 0, 0, 2, 0, 2, 0, 0, 0, 1, 1, 1, 0, 2, 1, 0, 1, 0, 0, 1, 1, 1 },
							{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 1, 0, 0, 2, 1, 0, 0, 0, 0, 0, 1 },
							{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 2, 0, 0, 1, 1, 0, 0, 0, 0, 1, 2, 0, 0 },
							{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 2, 0 },
							{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 2, 0, 2, 0, 1, 1, 1, 0, 2, 1, 0, 1, 2 },
							{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 1, 0, 0, 2, 1, 0, 1 },
							{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 2, 0, 0, 0, 1, 1, 0, 0, 2, 1, 0 }};
	
	/**
	 * Gibt an ob das Spiel noch l�uft false=nicht im Spiel, true=im Spiel
	 */
	private boolean inGame = false;
	
	/**
	 * Gibt an ob noch Ziegen gesetzt werden m�ssen. false=Es m�ssen keine Ziegen gesetzt werden. true=es m�ssen noch Ziegen gesetzt werden
	 */
	
	private boolean goatSetMode = true;
	
	/**
	 * Gibt an welcher Spieler momentan am Zug ist false=Ziege ture=Tieger
	 */
	private boolean player = false;
	/**
	 * Gibt an wie viele Ziegen bis her gefressen worden.
	 */
	private int eatenGoats = 0;
	/**
	 * Gibt an wie viele Ziegen noch zu S�tzen sind
	 */
	private int goatsToSet = 20;

	/**
	 * SetMovement realisiert das bewegen der Spielfiguren.
	 * 
	 * 
	 * @param startRow		Gibt an in Welcher Zeile Gestartet wird
	 * @param startColumn	repr�sentiert die Startspalte
	 * @param targetRow		Hier wird die Zielzeile �bergeben
	 * @param targetColumn	Gibt an welches die Zielspalte ist
	 * @return				Liefert den FehlerCode zur�ck {@link #isMoveAllowed}
	 */
	public int setMovement(int startRow, int startColumn, int targetRow, int targetColumn) {
		int playerCode;
		if (player) {
			playerCode = 2;
		} else {
			playerCode = 1;
		}
		int errorType = isMoveAllowed(startRow, startColumn, targetRow, targetColumn, playerCode);
		if (errorType == 0) {
			int moveAble = zuege[startRow * 5 + startColumn][targetRow * 5 + targetColumn];
			if (moveAble == 2) {
				int sheepRow = ((startRow - targetRow) / 2) + targetRow;
				int sheepColumn = ((startColumn - targetColumn) / 2) + targetColumn;
				field[sheepRow][sheepColumn] = 0;
				eatenGoats++;
			}

			field[startRow][startColumn] = 0;
			field[targetRow][targetColumn] = playerCode;
			winnerDetection();
			player = changePlayer(player);
			return 0;
		} else {
			return errorType;
		}
	}
	//zeige verschiebbar

	/**
	 * IsMoveAllowed �berpr�ft ob der Benutzer richtige Eingaben get�tigt hat. Hier werden die Spielregel �berpr�ft.
	 * 
	 * @param startRow		Gibt an in Welcher Zeile Gestartet wird
	 * @param startColumn	repr�sentiert die Startspalte
	 * @param targetRow		Hier wird die Zielzeile �bergeben
	 * @param targetColumn	Gibt an welches die Zielspalte ist
	 * @param playerCode	Gibt an welcher Spieler gerade an der Reihe ist. 1=Ziege, 2=Tiger
	 * @return				Gibt den Fehler zur�ck der erkannt wurde.
	 * <ol start="0">
	 * 	<li>Fehlerfrei</li>
	 * 	<li>Das Spiel ist beendet.</li>
	 * 	<li>Ziege darf noch nicht ziehen.</li>
	 * 	<li>Es wurde eine falsche Eingabe get�tigt.</li>
	 * 	<li>Eingegebene Werte zu gro�.</li>
	 * 	<li>Falscher Art gew�hlt.</li>
	 * 	<li>Ziel ist nicht frei.</li>
	 * 	<li>Zug nicht m�glich.</li>
	 * 	<li>Springen nicht M�glich.</li>
	 * </ol>
	 */
	public int isMoveAllowed(int startRow, int startColumn, int targetRow, int targetColumn, int playerCode) {
		if(!inGame){
			return 1;
		}
		if(goatSetMode&&!player){
			return 2;
		}
		if(startRow==-1||startColumn==-1||targetRow==-1||targetColumn==-1){
			return 3;
		}
		if (!(0 <= startRow && startRow <= 4 && 0 <= startColumn && startColumn <= 4 && 0 <= targetRow && targetRow <= 4
				&& 0 <= targetColumn && targetColumn <= 4)) {
			return 4;
		}
		if (field[startRow][startColumn] != playerCode) {
			return 5;
		}
		if (field[targetRow][targetColumn] != 0) {
			return 6;
		}
		int moveAble = zuege[startRow * 5 + startColumn][targetRow * 5 + targetColumn];
		if ((playerCode == 1 && moveAble != 1) || (playerCode == 2 && moveAble == 0)) {
			return 7;
		}
		int sheepRow = ((startRow - targetRow) / 2) + targetRow;
		int sheepColumn = ((startColumn - targetColumn) / 2) + targetColumn;
		if (field[sheepRow][sheepColumn] != 1 && moveAble==2) {
			return 8;//--------------------------------------------------------------------------------------------------
		}
		
		return 0;
	}

	/**
	 * SetSheepLocation �bernimmt das Setzen der Ziegen auf das Spielfeld
	 * 
	 * @param row		Gibt die Zeile an in der Die Ziege gesetzt werden soll.
	 * @param column	Gibt die Spalte an in der Die Ziege gesetzt werden soll.
	 * @return			Gibt den Fehler an der aufgetreten ist. {@link #isGoatLocationAllowed}
	 */
	public int setGoatLocation(int row, int column) {
		int errorType = isGoatLocationAllowed(row, column);
		if (errorType == 0) {
			field[row][column] = 1;
			goatsToSet--;
			if (goatsToSet == 0) {
				goatSetMode = false;
			}
			winnerDetection();
			player=changePlayer(player);
			return 0;
		} else {
			return errorType;
		}

	}

	/**
	 * IsSheepLocationAllowed �berpr�ft die Benutzereingaben.
	 * 
	 * @param row		Gibt die Zeile an in der Die Ziege gesetzt werden soll.
	 * @param column	Gibt die Spalte an in der Die Ziege gesetzt werden soll.
	 * @return			Gibt den Fehler an der erkannt wurde.
	 * <ol start="0">
	 * 	<li>Fehlerfrei</li>
	 * 	<li>Das Spiel ist beendet.</li>
	 * 	<li>Es wurden bereits alle Ziehen gesetzt.</li>
	 * 	<li>Es wurde eine falsche Eingabe get�tigt.</li>
	 * 	<li>Eingegebene Werte zu gro�.</li>
	 * 	<li>Feld ist schon besetzt</li>
	 * </ol>
	 */
	public int isGoatLocationAllowed(int row, int column) {
		if(!inGame){
			return 1;
		}
		if(!goatSetMode){
			return 2;
		}
		if(row==-1||column==-1){
			return 3;
		}
		if (!(0 <= row && row <= 4 && 0 <= column && column <= 4)) {
			return 4;
		}
		if (field[row][column] != 0) {
			return 5;
		}
		return 0;
	}

	/**
	 * WinnerDetection �berpr�ft ob ein Spieler gewonnen hat.
	 */
	public void winnerDetection() {
		inGame = false;
		for (int zeile = 0; zeile < field.length; zeile++) {
			for (int spalte = 0; spalte < field[zeile].length; spalte++) {
				if (field[zeile][spalte] == 2) {
					for (int zuegeRow = 0; zuegeRow < 25; zuegeRow++) {
						int zuegeColumn = zeile * 5 + spalte;
						int movePosibility = zuege[zuegeRow][zuegeColumn];
						if (movePosibility != 0 & field[zuegeRow % 5][zuegeRow / 5] == 0) {
							inGame = eatenGoats < 5;
						}
					}
				}
			}
		}
	}

	/**
	 * ChanhePlayer wechselt den Spieler
	 * 
	 * @param player	Aktueller Spieler
	 * @return 			Neuer Spieler
	 */
	public boolean changePlayer(boolean player) {
		return !player;
	}

	/**
	 * GetField lifer das Spielfeld zur�ck
	 * 
	 * @return	Spielfeld als 2D-int-Array {@link Model#field}
	 */
	public int[][] getField() {
		return field;
	}
	
	/**
	 * StartGAme started das Spiel
	 */
	public void startGame() {
		inGame = true;
	}

	/**
	 * IsInGame gibt zur�ck ob das Spiel noch l�uft
	 * 
	 * @return Gibt an ob das spiel l�uft. {@link Model#inGame}
	 */
	public boolean isInGame() {
		return inGame;
	}

	/**
	 * GetEatenSheeps liefert den Wert der gefressenen Ziegen zur�ck
	 * 
	 * @return Anzahl der Gefressenen Ziegen. {@link Model#eatenGoats}
	 */
	public int getEatenGoats() {
		return eatenGoats;
	}

	
	/**
	 * GetSheepsToSet gibt den Wert der noch zu setzende Zeigen zur�ck.
	 * 
	 * @return Anzahl der noch zu setzenden Ziegen. {@link Model#goatsToSet}
	 */
	public int getGoatsToSet() {
		return goatsToSet;
	}

	/**
	 * IsSheepSetMode liefert zur�ck ob noch Ziegen gesetzt werden m�ssen.
	 * 
	 * @return Gibt an ob noch Ziegen gesetzt werden m�ssen. {@link Model#sheepSetMode}
	 */
	public boolean isGoatSetMode() {
		return goatSetMode;
	}

	/**
	 * WhoPlays gibt zur�ck wer gerade am Zug ist.
	 * 
	 * @return Spieler.	Aktueller Spieler {@link Model#player}
	 */
	public boolean isPlayer() {
		return player;
	}
}
