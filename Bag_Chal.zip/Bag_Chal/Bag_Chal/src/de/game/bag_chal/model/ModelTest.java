package de.game.bag_chal.model;

import static org.junit.Assert.*;
import org.junit.Test;

public class ModelTest {
	@Test
	public void startTest() {
		Model model = new Model();
		model.startGame();
		assertTrue(model.isInGame());
	}
	//player--------------------------------------
	@Test
	public void playerTestAtStart(){
		Model model = new Model();
		assertFalse(model.isPlayer());
	}
	@Test
	public void playerChanhingTest(){
		Model model = new Model();
		assertTrue(model.changePlayer(model.isPlayer()));
	}
	//Field---------------------------------------
	@Test
	public void getFieldTest(){
		Model model = new Model();
		boolean test=true;
		int [][] field1 = new int[][]{{2,0,0,0,2},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{2,0,0,0,2}};
		int [][] field2 = model.getField();
		for (int i = 0; i < field2.length; i++) {
			for (int j = 0; j < field2[i].length; j++) {
				test=test&(field1[i][j]==field2[i][j]);
			}
		}
		assertTrue(test);
	}
	//asSheep --------------------------------------------------------------------------------------------------------------
	@Test
	public void sheepSetModeTest(){
		Model model = new Model();
		model.startGame();
		assertTrue(model.isGoatSetMode());
	}
	@Test
	public void getSheepToSetTest(){
		Model model = new Model();
		model.startGame();
		assertEquals(20,model.getGoatsToSet());
		model.setGoatLocation(2, 2);
		assertEquals(19,model.getGoatsToSet());
	}
	@Test
	public void isSheepLocationAllowedTest0(){
		Model model = new Model();
		model.startGame();
		assertEquals(0, model.isGoatLocationAllowed(2,2));
	}
	@Test
	public void isSheepLocationAllowedTest1(){
		Model model = new Model();
		assertEquals(1, model.isGoatLocationAllowed(2,2));
	}
	
	@Test
	public void isSheepLocationAllowedTest2(){
		Model model = new Model();
		model.startGame();
		setallgoats(model);
		assertEquals(2, model.isGoatLocationAllowed(100,100));
	}
	@Test
	public void isSheepLocationAllowedTest3(){
		Model model = new Model();
		model.startGame();
		assertEquals(3, model.isGoatLocationAllowed(-1,-1));
	}
	@Test
	public void isSheepLocationAllowedTest4(){
		Model model = new Model();
		model.startGame();
		assertEquals(4, model.isGoatLocationAllowed(100,100));
	}
	@Test
	public void isSheepLocationAllowedTest5(){
		Model model = new Model();
		model.startGame();
		assertEquals(5, model.isGoatLocationAllowed(0,0));
	}
	@Test
	public void setGoatLocationTest0(){
		Model model = new Model();
		model.startGame();
		assertEquals(0, model.setGoatLocation(2,2));
	}
	@Test
	public void setGoatLocationTest1(){
		Model model = new Model();
		assertEquals(1, model.setGoatLocation(2,2));
	}
	
	@Test
	public void setGoatLocationTest2(){
		Model model = new Model();
		model.startGame();
		setallgoats(model);
		assertEquals(2, model.setGoatLocation(100,100));
	}
	@Test
	public void setGoatLocationTest3(){
		Model model = new Model();
		model.startGame();
		assertEquals(3, model.setGoatLocation(-1,-1));
	}
	@Test
	public void setGoatLocationTest4(){
		Model model = new Model();
		model.startGame();
		assertEquals(4, model.setGoatLocation(100,100));
	}
	@Test
	public void setGoatLocationest5(){
		Model model = new Model();
		model.startGame();
		assertEquals(5, model.setGoatLocation(0,0));
	}
		
	//asTiger----------------------------------------------------------------------
	@Test
	public void isMoveAllowedTest0AsTiger(){
		Model model = new Model();
		model.startGame();
		model.setGoatLocation(2, 2);
		assertEquals(0, model.isMoveAllowed(0,0,1,1,2));
	}
	@Test
	public void isMoveAllowedTest1AsTiger(){
		Model model = new Model();
		model.setGoatLocation(2, 2);
		assertEquals(1, model.isMoveAllowed(0,0,1,1,2));
	}
	@Test
	public void isMoveAllowedTest3AsTiger(){
		Model model = new Model();
		model.startGame();
		model.setGoatLocation(2, 2);
		assertEquals(3, model.isMoveAllowed(-1,-1,-1,-1,2));
	}
	@Test
	public void isMoveAllowedTest4AsTiger(){
		Model model = new Model();
		model.startGame();
		model.setGoatLocation(2, 2);
		assertEquals(4, model.isMoveAllowed(9,2,1,2,2));
	}
	@Test
	public void isMoveAllowedTest5AsTiger(){
		Model model = new Model();
		model.startGame();
		model.setGoatLocation(2, 2);
		assertEquals(5, model.isMoveAllowed(2,2,2,2,2));
	}
	@Test
	public void isMoveAllowedTest6AsTiger(){
		Model model = new Model();
		model.startGame();
		model.setGoatLocation(2,2);
		assertEquals(6, model.isMoveAllowed(0,0,2,2,2));
	}
	@Test
	public void isMoveAllowedTest7AsTiger(){
		Model model = new Model();
		model.startGame();
		model.setGoatLocation(1, 0);
		assertEquals(7, model.isMoveAllowed(0,0,3,3,2));
	}
	@Test
	public void isMoveAllowedTest8AsTiger(){
		Model model = new Model();
		model.startGame();
		model.setGoatLocation(1, 0);
		assertEquals(8, model.isMoveAllowed(0,0,2,2,2));
	}
	@Test
	public void setMovementTest0AsTiger(){
		Model model = new Model();
		model.startGame();
		model.setGoatLocation(2, 2);
		assertEquals(0, model.setMovement(0,0,1,1));
	}
	@Test
	public void setMovementTest1AsTiger(){
		Model model = new Model();
		model.setGoatLocation(2, 2);
		assertEquals(1, model.setMovement(0,0,1,1));
	}
	@Test
	public void setMovementTest3AsTiger(){
		Model model = new Model();
		model.startGame();
		model.setGoatLocation(2, 2);
		assertEquals(3, model.setMovement(-1,-1,-1,-1));
	}
	@Test
	public void setMovementTest4AsTiger(){
		Model model = new Model();
		model.startGame();
		model.setGoatLocation(2, 2);
		assertEquals(4, model.setMovement(9,2,1,2));
	}
	@Test
	public void setMovementTest5AsTiger(){
		Model model = new Model();
		model.startGame();
		model.setGoatLocation(2, 2);
		assertEquals(5, model.setMovement(2,2,2,2));
	}
	@Test
	public void setMovementTest6AsTiger(){
		Model model = new Model();
		model.startGame();
		model.setGoatLocation(2,2);
		assertEquals(6, model.setMovement(0,0,2,2));
	}
	@Test
	public void setMovementTest7AsTiger(){
		Model model = new Model();
		model.startGame();
		model.setGoatLocation(1, 0);
		assertEquals(7, model.setMovement(0,0,3,3));
	}
	@Test
	public void setMovementTest8AsTiger(){
		Model model = new Model();
		model.startGame();
		model.setGoatLocation(1, 0);
		assertEquals(8, model.setMovement(0,0,2,2));
	}
	//Winner---------------------------------------------------------------------------------------
	@Test
	public void gewinntZiegeTest(){
		Model model = new Model();
		model.setGoatLocation(0, 3);
		model.setMovement(4, 4, 3, 3);
		model.setGoatLocation(0, 2);
		model.setMovement(3, 3, 4, 4);
		model.setGoatLocation(1, 4);
		model.setMovement(4, 4, 3, 3);
		model.setGoatLocation(2, 4);
		model.setMovement(3, 3, 4, 4);
		model.setGoatLocation(1, 3);
		model.setMovement(4, 4, 3, 3);
		model.setGoatLocation(2, 2);
		model.setMovement(3, 3, 4, 4);
		model.setGoatLocation(1, 1);
		model.setMovement(4, 4, 3, 3);
		model.setGoatLocation(0, 1);
		model.setMovement(3, 3, 4, 4);
		model.setGoatLocation(1, 0);
		model.setMovement(4, 4, 3, 3);
		model.setGoatLocation(2, 0);
		model.setMovement(3, 3, 4, 4);
		model.setGoatLocation(3, 0);
		model.setMovement(4, 4, 3, 3);
		model.setGoatLocation(3, 1);
		model.setMovement(3, 3, 4, 4);
		model.setGoatLocation(4, 1);
		model.setMovement(4, 4, 3, 3);
		model.setGoatLocation(4, 2);
		model.setMovement(3, 3, 4, 4);
		model.setGoatLocation(4, 3);
		model.setMovement(4, 4, 3, 3);
		model.setGoatLocation(3, 4);
		model.setMovement(3, 3, 4, 4);
		model.setGoatLocation(3, 3);
		assertFalse(model.isInGame()&&model.isPlayer());
	}
	
	@Test
	public void gewinntTiegerTest(){
		Model model = new Model();
		model.startGame();
		model.setGoatLocation(1, 1);
		model.setMovement(0, 0, 2, 2);
		model.setGoatLocation(1, 1);
		model.setMovement(2, 2, 0, 0);
		model.setGoatLocation(1, 1);
		model.setMovement(0, 0, 2, 2);
		model.setGoatLocation(1, 1);
		model.setMovement(2, 2, 0, 0);
		model.setGoatLocation(1, 1);
		model.setMovement(0, 0, 2, 2);
		assertFalse(model.isInGame()&&!model.isPlayer());
	}
	
	private void setallgoats(Model model){
		model.setGoatLocation(0,1);
		model.setMovement(0, 0, 1, 1);
		model.setGoatLocation(0, 2);
		model.setMovement(1, 1, 0, 0);
		model.setGoatLocation(0, 3);
		model.setMovement(0, 0, 1, 1);
		model.setGoatLocation(1, 0);
		model.setMovement(1, 1, 0, 0);
		model.setGoatLocation(1, 2);
		model.setMovement(0, 0, 1, 1);
		model.setGoatLocation(1, 3);
		model.setMovement(1, 1, 0, 0);
		model.setGoatLocation(1, 4);
		model.setMovement(0, 0, 1, 1);
		model.setGoatLocation(2, 0);
		model.setMovement(1, 1, 0, 0);
		model.setGoatLocation(2, 1);
		model.setMovement(0, 0, 1, 1);
		model.setGoatLocation(2, 2);
		model.setMovement(1, 1, 0, 0);
		model.setGoatLocation(2, 3);
		model.setMovement(0, 0, 1, 1);
		model.setGoatLocation(2, 4);
		model.setMovement(1, 1, 0, 0);
		model.setGoatLocation(3, 0);
		model.setMovement(0, 0, 1, 1);
		model.setGoatLocation(3, 1);
		model.setMovement(1, 1, 0, 0);
		model.setGoatLocation(3, 2);
		model.setMovement(0, 0, 1, 1);
		model.setGoatLocation(3, 3);
		model.setMovement(1, 1, 0, 0);
		model.setGoatLocation(3, 4);
		model.setMovement(0, 0, 1, 1);
		model.setGoatLocation(4, 1);
		model.setMovement(1, 1, 0, 0);
		model.setGoatLocation(4, 2);
		model.setMovement(0, 0, 1, 1);
		model.setGoatLocation(4, 3);
		model.setMovement(1, 1, 0, 0);
	}
}
