package de.game.bag_chal.view;

import de.game.bag_chal.model.Model;
/**
 * Die View ist verantwortlich alle f�r den Nutzer wichtigen Informationen auszugeben.<br> Es sind
 * Methoden enthalten um den Stand des Spielfeldes, und des aktuellen Spielzustands anzuzeigen.
 * Au�erdem werden Benutzereingaben angefordert. <br>Diese Klasse repr�sentiert die "View" des MVC-Paradigma.
 * 
 * @author Tobias Sigmann
 */

public class View {
	/**
	 * Instanz der Klasse Model, in der die zu zeichnenden Werte enthalten sind. {@link Model}
	 */
	Model model;

	/**
	 * View realisiert die Verkn�pfung zu einer Instanz der Klasse Model
	 * 
	 * @param model Instanz der klasse Model{@link Model}
	 */
	public View(Model model) {
		this.model = model;
	}

	/**
	 * PrintField realisiert die Ausgabe des Spielfeldes. Au�erdem wird 
	 * zus�tzlich die Anzahl der Gefressenen und zu setzenden Ziegen ausgegeben.
	 */
	public void printField() {
		int rowCounter=0;
		int[][] field = model.getField();
		System.out.println(" |0 1 2 3 4");
		System.out.println("-----------");
		for (int zeile = 0; zeile < field.length; zeile++) {
			System.out.print(rowCounter+"|");
			for (int spalte = 0; spalte < field[zeile].length; spalte++) {
				switch (field[zeile][spalte]) {
				case 0:
					System.out.print("+");
					break;
				case 1:
					System.out.print("Z");
					break;
				case 2:
					System.out.print("T");
					break;
				}
				if (spalte < 4) {
					System.out.print("-");
				} else {
					System.out.println();
				}
			}
			if (zeile < 4) {
				if (zeile % 2 == 0) {
					System.out.println(" ||\\|/|\\|/|");
				} else {
					System.out.println(" ||/|\\|/|\\|");
				}
			}
			rowCounter++;
		}
		System.out.println("Anzahl gefressener Ziegen: " + model.getEatenGoats());
		if (model.isGoatSetMode()) {
			System.out.println("Anzahl zu setzender Ziegen: " + model.getGoatsToSet());
		}

	}

	/**
	 * PrintPlayer gibt in der Konsole aus welcher Spieler gerade am Zug ist.
	 */
	public void printPlayer() {
		if (model.isPlayer()) {
			System.out.println("Spieler T ist am Zug");
		} else {
			System.out.println("Spieler Z ist am Zug");
		}
	}

	/**
	 * PrintSelectRow Schreibt in die Konsole die Eingabeanforderung einer Zeile.
	 * 
	 * @param type Gibt an ob Start - oder Zielzeile. false=Ziel, true=Start
	 */
	public void printSelectRow(boolean type) {
		if (type) {
			System.out.print("Zeile(Start): ");
		} else {
			System.out.print("Zeile(Ziel) : ");
		}

	}

	/**
	 * PrintSelectRow Schreibt in die Konsole die Eingabeanforderung einer Spalte
	 * 
	 * @param type Gibt an ob Start - oder Ziel Spalte. false=Zeil, true=Start
	 */
	public void printSelectColumn(boolean type) {
		if (type) {
			System.out.print("Spalte(Start): ");
		} else {
			System.out.print("Spalte(Ziel) : ");
		}
	}
	/**
	 * PrintUserSetSheepError schreibt den Fehler, der bei der Eingabe geschehen ist, in die Konsole.
	 * 
	 * @param userErrorType repr�sentiert den Fehler. {@link Model#isSheepLocationAllowed}
	 */
	public void printUserSetSheepError(int userErrorType) {
		switch (userErrorType) {
		case 1:
			System.out.println("Das Spiel ist beendet.");
			break;
		case 2:
			System.out.println("Es wurden bereits alle Ziehen gesetzt.");
			break;
		case 3:
			System.out.println("Es wurde eine falsche Eingabe get�tigt.");
			break;
		case 4:
			System.out.println("Eingegebene Werte zu gro�.");
			break;
		case 5:
			System.out.println("Feld ist schon besetzt.");
			break;
		default:
			break;
		}
	}

	/**
	 * PrintUserMoveError gibt den Fehler, der bei der Eingabe durch den Benutzer aufgetreten ist, als Text auf der Konsole aus.
	 * 
	 * @param userErrorType repr�sentiert welcher Fehler aufgetreten ist. {@link Model#isMoveAllowed}
	 */
	public void printUserMoveError(int userErrorType) {
		switch (userErrorType) {
		case 1:
			System.out.println("Das Spiel ist beendet.");
			break;
		case 2:
			System.out.println("Ziege darf noch nicht ziehen.");
			break;
		case 3:
			System.out.println("Es wurde eine falsche Eingabe get�tigt.");
			break;
		case 4:
			System.out.println("Eingegebene Werte zu gro�.");
			break;
		case 5:
			System.out.println("Falscher Art gew�hlt.");
			break;
		case 6:
			System.out.println("Ziel ist nicht frei.");
			break;
		case 7:
			System.out.println("Zug nicht m�glich.");
			break;
		case 8:
			System.out.println("Springen nicht M�glich.");
			break;
		default:
			break;

		}
	}

	/**
	 * PrintWinner schreibt den Gewinner in die Konsole.
	 * 
	 * @param player gibt an wer gewonnen hat. false=Ziege, true=Tiger
	 */
	public void printWinner(boolean player) {
		if (player) {
			System.out.println("Spieler T hat gewonnen");
		} else {
			System.out.println("Spieler Z hat gewonnen");
		}
	}
}
